//
//  XLViewController.swift
//  MovieFan-ios
//
//  Created by Xmartlabs SRL ( https://xmartlabs.com )
//  Copyright © 2016 Xmartlabs SRL. All rights reserved.
//

import Foundation
import UIKit
import RxCocoa
import RxSwift

class XLViewController: UIViewController {
    let disposeBag = DisposeBag()

}
